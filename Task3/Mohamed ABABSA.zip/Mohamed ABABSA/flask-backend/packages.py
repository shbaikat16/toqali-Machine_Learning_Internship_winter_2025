import pickle
import sklearn 
import numpy
import pandas 

print("pickle:", pickle.format_version)
print("sklearn:", sklearn.__version__)
print("numpy:", numpy.__version__)
print("pandas:", pandas.__version__)