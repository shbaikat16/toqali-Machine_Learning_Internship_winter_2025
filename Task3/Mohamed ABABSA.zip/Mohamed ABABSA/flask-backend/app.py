from flask import Flask, request, jsonify
from flask_cors import CORS
import pandas as pd
import pickle
from datetime import datetime, timedelta
import random
import uuid
import os

app = Flask(__name__)
CORS(app)  # Enable CORS for React frontend

# Load the model and scaler
try:
    with open('./models/random_forest_model.pkl', 'rb') as f:
        model = pickle.load(f)
    print("Model loaded successfully.")
except Exception as e:
    print(f"Error loading model: {e}")

try:
    with open('./models/scaler_standard.pkl', 'rb') as f:
        scaler = pickle.load(f)
    print("Scaler loaded successfully.")
except Exception as e:
    print(f"Error loading scaler: {e}")

# Meal mapping
meal_mapping = {
    'Not Selected': 0,
    'Meal Plan 1': 1,
    'Meal Plan 2': 2,
    'Meal Plan 3': 3
}

COLLECTED_DATA_PATH = "./dataset/collected_bookings.csv"

# Root route
@app.route('/')
def home():
    return "Welcome to the Hotel Booking Prediction API! Use the /predict endpoint to make predictions."

def transform_booking_data(data):
    # Mapping frontend keys to backend expected keys
    key_mapping = {
        "numberOfAdults": "number of adults",
        "numberOfChildren": "number of children",
        "typeOfMeal": "type of meal",
        "carParkingSpace": "car parking space",
        "roomType": "room type",
        "marketSegmentType": "market segment type",
        "repeated": "repeated",
        "previousCancellations": "P-C",
        "pastBookingsNotCanceled": "P-not-C",
        "averagePrice": "average price",
        "specialRequests": "special requests",
        "dateOfReservation": "date of reservation",
        "arrivalDate": "arrival date",
        "departureDate": "departure date",
    }

    # Mapping meal plan numbers to names
    Meal_mapping = {
        "1": "Meal Plan 1",
        "2": "Meal Plan 2",
        "3": "Meal Plan 3",
        "4": "Meal Plan 4",
    }

    # Mapping room type numbers to names
    room_mapping = {
        "1": "Room_Type 1",
        "2": "Room_Type 2",
        "3": "Room_Type 3",
        "4": "Room_Type 4",
        "5": "Room_Type 5",
        "6": "Room_Type 6",
        "7": "Room_Type 7",
    }

    transformed_data = {}

    for old_key, new_key in key_mapping.items():
        if old_key in data:
            value = data[old_key]

            # Convert meal plan numbers to their names
            if old_key == "typeOfMeal":
                value = Meal_mapping.get(value, value)

            # Convert room type numbers to their names
            if old_key == "roomType":
                value = room_mapping.get(value, value)

            # Format dates from YYYY-MM-DD to MM/DD/YYYY
            if old_key in ["dateOfReservation", "arrivalDate", "departureDate"]:
                try:
                    value = datetime.strptime(value, "%Y-%m-%d").strftime("%m/%d/%Y")
                except ValueError:
                    pass  # Keep original if format is invalid
            
            # Convert strings representing numbers to integers
            if isinstance(value, str) and value.isdigit():
                value = int(value)

            # Store transformed key-value pair
            transformed_data[new_key] = value

    return transformed_data

def calculate_weekend_week_nights(arrival_date_str, departure_date_str):
    # Ensure arrival_date_str and departure_date_str are datetime objects (pandas.Timestamp can be directly used)
    arrival_date = arrival_date_str if isinstance(arrival_date_str, datetime) else pd.to_datetime(arrival_date_str)
    departure_date = departure_date_str if isinstance(departure_date_str, datetime) else pd.to_datetime(departure_date_str)
    # Initialize counters
    weekend_nights = 0
    week_nights = 0

    # Loop through each day between arrival and departure dates
    current_date = arrival_date
    while current_date <= departure_date:
        # Check if the day is a weekend (Saturday or Sunday)
        if current_date.weekday() >= 5:  # Saturday = 5, Sunday = 6
            weekend_nights += 1
        else:
            week_nights += 1
        current_date += timedelta(days=1)

    return weekend_nights, week_nights

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get data from the request
        data = request.json
        data = transform_booking_data(data)
        

        # Generate unique Booking ID
        unique_number = random.randint(10000, 99999)  # Generates a random 5-digit number
        booking_id = f"INN{unique_number}"

        # Ensure both dates are received
        if 'date of reservation' not in data or 'arrival date' not in data or 'departure date' not in data:
            return jsonify({'error': "Reservation date, arrival date, and departure date are required"}), 400

        # Convert dates to datetime format
        date_of_reservation = pd.to_datetime(data['date of reservation'])
        arrival_date = pd.to_datetime(data['arrival date'])
        departure_date = pd.to_datetime(data['departure date'])        

        # Calculate lead time (difference in days)
        lead_time = (arrival_date - date_of_reservation).days
        if lead_time < 0:
            return jsonify({'error': 'Arrival date cannot be earlier than reservation date'}), 400
        
        # Calculate weekend and week nights
        weekend_nights, week_nights = calculate_weekend_week_nights(arrival_date, departure_date)

        # Add the new values to the input data
        data['Booking_ID'] = booking_id
        data['lead time'] = lead_time
        data['number of weekend nights'] = weekend_nights
        data['number of week nights'] = week_nights


        # Define the expected columns (with exact feature names from training)
        columns = [
            'Booking_ID', 'number of adults', 'number of children',
            'number of weekend nights', 'number of week nights', 'type of meal',
            'car parking space', 'room type', 'lead time', 'market segment type',
            'repeated', 'P-C', 'P-not-C', 'average price', 'special requests',
            'date of reservation'
        ]

        # Create a DataFrame with the expected columns
        input_data = pd.DataFrame([data], columns=columns)

        # Transformations
        # 1. Extract numeric part from Booking_ID
        input_data['Booking_ID'] = input_data['Booking_ID'].str.extract('(\d+)').astype(int)
        

        # 2. Map meal type to numeric values
        input_data['type of meal'] = input_data['type of meal'].map(meal_mapping)
        

        # 3. Extract numeric part from room type
        #input_data['room type'] = input_data['room type'].str.extract('(\d+)').astype(int)
        

        # 4. One-hot encode market segment type
        input_data = pd.get_dummies(input_data, columns=['market segment type'], prefix='segment', drop_first=True)

        # Ensure all segment columns are present (in case some are missing in the input)
        segment_cols = [f'segment_{i}' for i in ['Online', 'Offline', 'Corporate', 'Complementary']]
        for col in segment_cols:
            if col not in input_data.columns:
                input_data[col] = 0

        # Convert segment columns to integer
        input_data[segment_cols] = input_data[segment_cols].astype(int)

        # 5. Convert 'average price' to float
        input_data['average price'] = input_data['average price'].astype(float)

        # 6. Extract features from date of reservation
        input_data['date of reservation'] = pd.to_datetime(input_data['date of reservation'])
        input_data['year'] = input_data['date of reservation'].dt.year
        input_data['month'] = input_data['date of reservation'].dt.month
        input_data['day'] = input_data['date of reservation'].dt.day
        input_data['day_of_week'] = input_data['date of reservation'].dt.weekday  # Monday=0, Sunday=6
        input_data['is_weekend'] = (input_data['day_of_week'] >= 5).astype(int)  # 1 if Sat/Sun, else 0
        input_data['quarter'] = input_data['date of reservation'].dt.quarter
        # Convert 'date of reservation' back to string
        input_data['date of reservation'] = input_data['date of reservation'].dt.strftime('%m-%d-%Y')

        # Reindex the columns to match the exact order used during training
        correct_order = [
            'Booking_ID', 'number of adults', 'number of children',
            'number of weekend nights', 'number of week nights', 'type of meal',
            'car parking space', 'room type', 'lead time', 'repeated',
            'P-C', 'P-not-C', 'average price', 'special requests',
            'segment_Complementary', 'segment_Corporate', 'segment_Offline', 'segment_Online',
            'year', 'month', 'day', 'day_of_week', 'is_weekend', 'quarter'
        ]
        input_data = input_data.reindex(columns=correct_order)

        # Scale the input data
        # Strip spaces from column names in both DataFrame and Scaler
        input_data.columns = input_data.columns.str.strip()
        scaler.feature_names_in_ = [col.strip() for col in scaler.feature_names_in_]
        scaled_data = scaler.transform(input_data)

        # Make prediction
        prediction = model.predict(input_data)
        print("Prediction made successfully:", prediction)

        # Save collected data to CSV
        if not os.path.exists(COLLECTED_DATA_PATH):
            input_data.to_csv(COLLECTED_DATA_PATH, mode='w', index=False, header=True)
        else:
            input_data.to_csv(COLLECTED_DATA_PATH, mode='a', index=False, header=False)

        print(f"Data saved successfully to {COLLECTED_DATA_PATH}")

        # Return the prediction
        return jsonify({'prediction': int(prediction[0])})
    except Exception as e:
        print(f"Error during prediction: {e}")
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)