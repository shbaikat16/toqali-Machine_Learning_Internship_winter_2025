import React from 'react';

const Navbar = () => {
  return (
    <header style={styles.navbar}>
      <div style={styles.leftSection}>
        <img src="/logo.png" alt="HotelInsight" style={styles.logo} />
        <h1 style={styles.appName}>HotelInsight</h1>
      </div>
      <nav style={styles.rightSection}>
        <a href="#about" style={styles.navLink}>About</a>
        <a href="#booking" style={styles.navLink}>Booking</a>
      </nav>
    </header>
  );
};

const styles = {
  navbar: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '10px 20px',
    backgroundColor: '#f9f9f9',
    borderBottom: '1px solid #ddd',
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
  },
  leftSection: {
    display: 'flex',
    alignItems: 'center',
  },
  logo: {
    width: '80px',
    height: '80px',
    marginRight: '10px',
  },
  appName: {
    margin: 0,
    fontSize: '1.5rem',
    color: '#333',
  },
  rightSection: {
    display: 'flex',
    gap: '20px',
  },
  navLink: {
    textDecoration: 'none',
    color: '#007bff',
    fontSize: '1rem',
  },
};

export default Navbar;