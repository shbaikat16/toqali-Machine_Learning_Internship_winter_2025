// src/components/Footer.js
import React from 'react';

const Footer = () => {
  return (
    <footer style={styles.footer}>
      <div style={styles.content}>
        <h3 style={styles.heading}>Contact Us</h3>
        <p style={styles.text}>Email: support@hotelinsight.com</p>
        <p style={styles.text}>Phone: +1 (123) 456-7890</p>
        <p style={styles.text}>Address: 123 HotelInsight Lane, Tech City, TX 12345</p>
      </div>
    </footer>
  );
};

const styles = {
  footer: {
    padding: '20px',
    textAlign: 'center',
    borderTop: '1px',
    marginTop: 'auto', // Ensures the footer sticks to the bottom
  },
  content: {
    maxWidth: '800px',
    margin: '0 auto',
  },
  heading: {
    margin: '0 0 10px',
    fontSize: '1.5rem',
  },
  text: {
    margin: '5px 0',
    fontSize: '1rem',
  },
  socialLinks: {
    marginTop: '10px',
    display: 'flex',
    justifyContent: 'center',
    gap: '15px',
  },
  link: {
    color: '#007bff',
    textDecoration: 'none',
    fontSize: '1rem',
  },
  linkHover: {
    textDecoration: 'underline',
  },
};

export default Footer;