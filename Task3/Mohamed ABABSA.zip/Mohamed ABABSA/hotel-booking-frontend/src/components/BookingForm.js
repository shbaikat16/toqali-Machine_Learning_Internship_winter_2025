import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCheckCircle, faTimesCircle } from "@fortawesome/free-solid-svg-icons";

const BookingForm = () => {
  // Initialize state
  const [formData, setFormData] = useState({
    numberOfAdults: 0,
    numberOfChildren: 0,
    typeOfMeal: 0,
    carParkingSpace: 0, 
    previousCancellations: 0,
    pastBookingsNotCanceled: 0,
    averagePrice: '',
    roomType: 1,
    marketSegmentType: 'Offline',
    repeated: 0,
    specialRequests: 0,
    dateOfReservation: '',
    arrivalDate: '',
    departureDate: '',
  });

  const [prediction, setPrediction] = useState(null);
  const predictionCardRef = useRef(null);

  // Function to handle clicks outside the prediction card
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (predictionCardRef.current && !predictionCardRef.current.contains(event.target)) {
        setPrediction(null); // Close the card
      }
    };

    // Add event listener when the prediction card is shown
    if (prediction !== null) {
      document.addEventListener('mousedown', handleClickOutside);
    }

    // Clean up the event listener
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [prediction]);

  // Handle form data changes
  const handleChange = (e) => {
    const { name, value } = e.target;
  
    let newValue = value;
    if (name === "carParkingSpace" || name === "repeated") {
    newValue = value === "Yes" ? 1 : 0;
    }
  
    setFormData({ ...formData, [name]: newValue });
  };

  // Increment function for number fields
  const handleIncrement = (field) => {
    setFormData((prevData) => ({
      ...prevData,
      [field]: prevData[field] + 1,
    }));
  };

  // Decrement function for number fields
  const handleDecrement = (field) => {
    setFormData((prevData) => ({
      ...prevData,
      [field]: prevData[field] > 0 ? prevData[field] - 1 : 0,
    }));
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://127.0.0.1:5000/predict', formData);
      setPrediction(response.data.prediction);
    } catch (error) {
      console.error('Error making prediction:', error);
    }
  };

  return (
    <div className="booking-form">
      <h2>Hotel Booking Prediction Form</h2>
      <form onSubmit={handleSubmit}>
        {/* First Row: Reservation Date, Arrival Date, Number of Adults, Number of Children */}
        <div className="first-row">
          <div className="input-group">
            <label>Reservation Date:</label>
            <input
              type="date"
              name="dateOfReservation"
              value={formData.dateOfReservation}
              onChange={handleChange}
            />
          </div>

          <div className="input-group">
            <label>Arrival Date:</label>
            <input
              type="date"
              name="arrivalDate"
              value={formData.arrivalDate}
              onChange={handleChange}
            />
          </div>

          <div className="input-group">
            <label>Departure Date:</label>
            <input
              type="date"
              name="departureDate"
              value={formData.departureDate}
              onChange={handleChange}
            />
          </div>

          <div className="input-group">
            <label>Number of Adults:</label>
            <div className="spinner">
              <button type="button" onClick={() => handleDecrement('numberOfAdults')}>-</button>
              <input
                type="text"
                name="numberOfAdults"
                value={formData.numberOfAdults}
                readOnly
              />
              <button type="button" onClick={() => handleIncrement('numberOfAdults')}>+</button>
            </div>
          </div>

          <div className="input-group">
            <label>Number of Children:</label>
            <div className="spinner">
              <button type="button" onClick={() => handleDecrement('numberOfChildren')}>-</button>
              <input
                type="text"
                name="numberOfChildren"
                value={formData.numberOfChildren}
                readOnly
              />
              <button type="button" onClick={() => handleIncrement('numberOfChildren')}>+</button>
            </div>
          </div>
        </div>

        {/* Second Row: Type of Meal, Room Type, Special Requests */}
        <div className="second-row">
          <div className="input-group">
            <label>Type of Meal:</label>
            <select name="typeOfMeal" value={formData.typeOfMeal} onChange={handleChange}>
              <option value={0}>Not Selected</option>
              <option value={1}>Meal Plan 1</option>
              <option value={2}>Meal Plan 2</option>
              <option value={3}>Meal Plan 3</option>
            </select>
          </div>

          <div className="input-group">
            <label>Room Type:</label>
            <select name="roomType" value={formData.roomType} onChange={handleChange}>
              {[...Array(7)].map((_, index) => (
                <option key={index + 1} value={index + 1}>Room Type {index + 1}</option>
              ))}
            </select>
          </div>

          <div className="input-group">
            <label>Special Requests:</label>
            <select name="specialRequests" value={formData.specialRequests} onChange={handleChange}>
              <option value={0}>0</option>
              <option value={1}>1</option>
              <option value={2}>2</option>
              <option value={3}>3</option>
              <option value={4}>4</option>
              <option value={5}>5</option>
            </select>
          </div>
        </div>

        {/* Third Row: Car Parking Space, Previous Cancellations, Past Bookings Not Canceled, Average Price */}
        <div className="third-row">
          <div className="input-group">
            <label>Car Parking Space:</label>
            <div className="radio-group">
              <input
                type="radio"
                id="carParkingYes"
                name="carParkingSpace"
                value="Yes"
                checked={formData.carParkingSpace === 1}
                onChange={handleChange}
              />
              <label htmlFor="carParkingYes">Yes</label>
              <input
                type="radio"
                id="carParkingNo"
                name="carParkingSpace"
                value="No"
                checked={formData.carParkingSpace === 0}
                onChange={handleChange}
              />
              <label htmlFor="carParkingNo">No</label>
            </div>
          </div>

          <div className="input-group">
            <label>Previous Cancellations:</label>
            <input
              type="number"
              name="previousCancellations"
              value={formData.previousCancellations}
              onChange={handleChange}
              min="0"
            />
          </div>

          <div className="input-group">
            <label>Past Bookings Not Canceled:</label>
            <input
              type="number"
              name="pastBookingsNotCanceled"
              value={formData.pastBookingsNotCanceled}
              onChange={handleChange}
              min="0"
            />
          </div>

          <div className="input-group">
            <label>Average Price per Night (€):</label>
            <input
              type="text"
              name="averagePrice"
              value={formData.averagePrice}
              onChange={handleChange}
              pattern="[0-9]*"  // Only numbers allowed
              title="Please enter a valid number"
            />
          </div>
        </div>

        {/* Fourth Row: Repeated and Market Segment */}
        <div className='fourth-row'>
            <div className='input-group'>
            <label>Repeated:</label>
            <div className="radio-group">
              <input
                type="radio"
                id="repeatedYes"
                name="repeated"
                value="Yes"
                checked={formData.repeated === 1}
                onChange={handleChange}
              />
              <label htmlFor="repeatedYes">Yes</label>
              <input
                type="radio"
                id="repeatedNo"
                name="repeated"
                value="No"
                checked={formData.repeated === 0}
                onChange={handleChange}
              />
              <label htmlFor="repeatedNo">No</label>
            </div>
            </div>

            <div className='input-group'>
            <label>
            Market Segment:
            <select name="marketSegmentType" value={formData.marketSegmentType} onChange={handleChange}>
                <option value="Offline">Offline</option>
                <option value="Online">Online</option>
                <option value="Corporate">Corporate</option>
                <option value="Aviation">Aviation</option>
                <option value="Complementary">Complementary</option>
            </select>
            </label>
            </div>
        </div>

        <button type="submit">Predict</button>
      </form>

      {prediction !== null && (
        <div className="prediction-card" ref={predictionCardRef}>
          <FontAwesomeIcon
            icon={prediction === 0 ? faCheckCircle : faTimesCircle}
            className={`prediction-icon ${prediction === 0 ? "prediction-success" : "prediction-failed"}`}
          />
          <h3>{prediction === 0 ? "Booking is Confirmed" : "Booking is at Risk of Cancellation"}</h3>
          <button onClick={() => setPrediction(null)}>Close</button>
        </div>
      )}
    </div>
  );
};

export default BookingForm;
