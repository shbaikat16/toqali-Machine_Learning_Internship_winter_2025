import React from 'react';

const About = () => {
  return (
    <section id="about" style={styles.aboutSection}>
      <div style={styles.content}>
        <h2>About HotelInsight</h2>
        <p>
        &#x1F917; Welcome to <strong>HotelInsight</strong> your smart assistant for hotel booking predictions!  
        Our web application leverages the power of advanced machine learning to help you make informed decisions about your reservations.  
        Whether you're planning a trip or managing multiple bookings, HotelInsight provides reliable insights to enhance your experience and minimize uncertainties.  
        </p>
      </div>
    </section>
  );
};

const styles = {
  aboutSection: {
    padding: '100px 20px 20px', // Extra padding at the top to account for the fixed navbar
    textAlign: 'center',
  },
  content: {
    maxWidth: '800px',
    margin: '0 auto',
  },
};

export default About;