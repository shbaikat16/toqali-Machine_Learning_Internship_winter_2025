import React from 'react';
import Navbar from './components/Navbar';
import About from './components/About';
import BookingForm from './components/BookingForm';
import Footer from './components/Footer';
import './App.css';

function App() {
  return (
    <div className="App">
      <Navbar />
      <div className="container">
        <About />
        <p>📝 Let's get started! Provide some booking details, and our intelligent system will predict your reservation status using advanced machine learning.</p>
        <BookingForm />
      </div>
      <Footer />
    </div>
  );
}

export default App;