# HotelInsight Web App

This is a web application built with Flask for the backend and React for the frontend.

## Backend Setup (Flask)
1. Navigate to the backend directory:
   ```sh
   cd flask-backend/
   ```
2. Install dependencies:
   ```sh
   pip install -r requirements.txt
   ```
3. Run the Flask backend:
   ```sh
   python app.py
   ```

## Frontend Setup (React)
1. Ensure you have Node.js and npm installed.
2. Navigate to the frontend directory:
   ```sh
   cd hotel-booking-frontend/
   ```
3. Install dependencies:
   ```sh
   npm install
   ```
4. Start the React app:
   ```sh
   npm start
   ```

## Additional Libraries
Ensure the following FontAwesome icons are installed in the frontend:
```sh
npm install --save @fortawesome/react-fontawesome @fortawesome/free-solid-svg-icons
```

Ensure Axios is installed for API requests:
```sh
npm install axios
```

## Dependencies Versions
- **Backend:**
  - pickle: 4.0
  - sklearn: 1.6.1
  - numpy: 1.26.4
  - pandas: 2.2.2
  - Flask: 1.1.2
  - Flask-Cors: 5.0.0

- **Frontend:**
  - Node.js: v22.14.0
  - npm: 10.2.4

Enjoy!