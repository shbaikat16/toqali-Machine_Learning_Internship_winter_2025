import pickle
import xgboost as xgb
import pandas as pd
import numpy as np
import os
from flask import Flask, request, render_template, jsonify

app = Flask(__name__)

# Load the trained model
MODEL_PATH = "C:/Users/ASUS/Downloads/Task 3 Reem Hindi/models/xgb_trained_modelnew2.pkl"
with open(MODEL_PATH, "rb") as f:
    model = pickle.load(f)

# Define expected feature columns (make sure they match the training data)
feature_columns = [
    "car_parking_space", "lead_time", "repeated", "average_price",
    "special_requests", "year", "month", "is_weekend",
    "total_nights", "guest_type",
    "market_segment_encoded", 
    "room_type_Room_Type_1", "room_type_Room_Type_2", "room_type_Room_Type_3",
    "room_type_Room_Type_4", "room_type_Room_Type_5", "room_type_Room_Type_6", "room_type_Room_Type_7",
    "type_of_meal_Meal_Plan_1", "type_of_meal_Meal_Plan_2", "type_of_meal_Meal_Plan_3", "type_of_meal_Not_Selected"
]

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        try:
            # Debug: Print the received form data
            print("Received form data:", request.form)

            # Retrieve form data
            form_data = {col: request.form.get(col, 0) for col in feature_columns}

            # Convert to DataFrame (Ensure correct types)
            input_data = pd.DataFrame([form_data], dtype=float)

            # Ensure it has the correct shape
            if input_data.shape[1] != len(feature_columns):
                return jsonify({"error": f"Feature shape mismatch, expected: {len(feature_columns)}, got {input_data.shape[1]}"})

            # Make prediction
            prediction = model.predict(input_data)[0]
            result = "Booking Confirmed ✅" if prediction == 1 else "Booking Canceled ❌"

            return render_template("index.html", prediction=result)
        
        except Exception as e:
            return jsonify({"error": str(e)})

    return render_template("index.html", prediction=None)

if __name__ == "__main__":
    app.run(debug=True)
