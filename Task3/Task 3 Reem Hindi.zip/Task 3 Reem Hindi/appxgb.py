from flask import Flask, request, jsonify, render_template
import pickle
import numpy as np

app = Flask(__name__)

# Load the trained model
MODEL_PATH = "C:/Users/ASUS/Downloads/models/xgb_trained_model.pkl"
with open(MODEL_PATH, "rb") as f:
    model = pickle.load(f)

print("✅ Model loaded successfully!")

@app.route("/", methods=["GET", "POST"])
def home():
    prediction = None
    if request.method == "POST":
        try:
            # Get input values from form
            input_data = [float(request.form["feature1"]), float(request.form["feature2"])]
            input_data = np.array(input_data).reshape(1, -1)

            # Make prediction
            prediction = model.predict(input_data)[0]

        except Exception as e:
            prediction = f"Error: {e}"

    return render_template("index.html", prediction=prediction)

if __name__ == "__main__":
    app.run(debug=True)
